﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maturski_ispit_A6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-798ME2F\SQLEXPRESS;Initial Catalog=4EIT_А6_PolovniAutomobili;Integrated Security=True"); /* MM 2 sp*/

        SqlCommand kom = new SqlCommand();

        SqlDataReader dr;

        int id = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
            PuniListBoxModeli();

        }
        private void PuniListBoxModeli()
        {
            /* Kon.Open();
             SqlCommand cmd = new SqlCommand("PuniListBoxModeli", Kon);
             cmd.CommandType = CommandType.StoredProcedure;
             cmd.ExecuteNonQuery();
             DataTable dt = new DataTable();
             dt.Load(cmd.ExecuteReader());
             listBox1.DataSource = dt;
             listBox1.DisplayMember = "ModelAutomobila";
             Kon.Close(); */

            kom.Connection = Kon;
            kom.CommandText = "EXEC PuniListBoxModeli";

            Kon.Open();

            dr = kom.ExecuteReader();

            while (dr.Read())
            {
                listBox1.Items.Add(dr["ModelAutomobila"]);
            }

            Kon.Close();

        }
        private void PuniListBoxModeluSLOV()
        {

            /*Kon.Open();
            SqlCommand cmd = new SqlCommand("PuniListBoxUslov", Kon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ModelID", SqlDbType.VarChar).Value = textBox2.Text.ToString();
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            listBox1.DataSource = dt;
            listBox1.DisplayMember = "Model";
            Kon.Close(); */
        }
        private void UpdateModela()
        {
            string Par_Model = listBox1.Text.ToString();
            string[] PModel = Par_Model.Split('-');

            string Par_Naziv = textNazivModel.Text.ToString();
            string[] PNaziv = Par_Naziv.Split('-');

            Kon.Open();
            SqlCommand cmd = new SqlCommand("IzmeniModel", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@ModelNaziv", SqlDbType.VarChar).Value = PNaziv[1].ToString().Trim();
            cmd.Parameters.AddWithValue("@ModelID", SqlDbType.VarChar).Value = PModel[0].ToString().Trim();

            cmd.ExecuteNonQuery();

            Kon.Close();

        }
        private void PuniChartGrid()
        {

            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniGridChart", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@GodisteOD", SqlDbType.VarChar).Value = numericOD.Value.ToString();
            cmd.Parameters.AddWithValue("@GodisteDO", SqlDbType.VarChar).Value = numericDO.Value.ToString();
            cmd.Parameters.AddWithValue("@Kilometraza", SqlDbType.VarChar).Value = txtKilometraza.Text.ToString();

            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            chart1.DataSource = dt;

            chart1.Series["Series1"].XValueMember = "Proizvodjac";
            chart1.Series["Series1"].YValueMembers = "BrVozila";
            chart1.Titles.Add("AUTOMOBILI");

            dataGridView1.DataSource = dt;

            Kon.Close();

        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            UpdateModela();
            listBox1.Items.Clear(); /*MORAJU SE OBRISATI SVI PODACI IZ COLLECTION I PONOVO POZVATI METODA PuniListBoxModeli() DA BI IZMENE BILE VIDLJIVE*/
            PuniListBoxModeli();
            BrisanjeKontrolaLB();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = listBox1.SelectedIndex;
            if (index != -1)
            {
                string Par_Model = listBox1.Text.ToString();
                string[] PModel = Par_Model.Split('-');
                comboProizvodjac.Text = PModel[2].ToString().Trim();
                textNazivModel.Text = PModel[2].ToString().Trim() + " - " + PModel[1].ToString().Trim();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPrikazi_Click(object sender, EventArgs e)
        {
            chart1.Titles.Clear();
            PuniChartGrid();
        }

        private void btnTrazi_Click(object sender, EventArgs e)
        {
            listBox1.SelectedItems.Clear(); /*U OVOM DELU SE PRETRAZUJE KOLEKCIJA PODATAKA IZ LISTBOX-A */
            for (int i = listBox1.Items.Count - 1; i >= 0; i--)
            {
                if (listBox1.Items[i].ToString().ToLower().Contains(textBox2.Text.ToLower()))
                {
                    listBox1.SetSelected(i, true); /*OVDE SE POSTAVLJA NA TRAZENI PODATAK*/
                }
            }
        }
        private void ModeliA_Click(object sender, EventArgs e)
        {

        }
        private void BrisanjeKontrolaLB()
        {
            textNazivModel.Clear();
            //txtNazivProizvodaLB.Clear();
            comboProizvodjac.Text = "";
        }

        private void listBox1_Click(object sender, EventArgs e)
        {
            //string Par_Model = listBox1.Text.ToString();
            //string[] PModel = Par_Model.Split('-');
            //comboProizvodjac.Text = PModel[2].ToString().Trim();
            //textNazivModel.Text = PModel[2].ToString().Trim() + "  " + PModel[1].ToString().Trim();
        }

        private void btnIzadji2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            //PuniListBoxModeluSLOV();
            /*PRETRAGA PO OVOM DOGADJAJU GDE SE KORISTILA SQL PROCEDURA NIJE VISE POTREBNA*/
        }

    }
}
