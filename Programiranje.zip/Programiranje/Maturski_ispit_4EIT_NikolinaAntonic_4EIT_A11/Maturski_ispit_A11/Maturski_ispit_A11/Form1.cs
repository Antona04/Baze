﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maturski_ispit_A11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-798ME2F\SQLEXPRESS;Initial Catalog=4EIT_A11_EvidencijaKnjiga;Integrated Security=True"); /* MM 2 sp*/

        SqlCommand kom = new SqlCommand();

        SqlDataReader dr;

        int id = 0;
        private void izlazToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PuniListBox();
        }

        private void PuniListBox()
        {
            txtSifra.Enabled = false;
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniListBox", Kon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            listBox1.DataSource = dt;
            listBox1.DisplayMember = "Autor";

            Kon.Close();

        }

        private void listBox1_Click(object sender, EventArgs e)
        {
            string Par_Autor = listBox1.Text.ToString();
            string[] PAutor = Par_Autor.Split('-');

            txtSifra.Text = PAutor[0].ToString().Trim();
            txtIme.Text = PAutor[1].ToString().Trim();
            txtPrezime.Text = PAutor[2].ToString().Trim();
            dtpDatum.Value = Convert.ToDateTime(PAutor[3].ToString().Trim());
        }

        private void InsertAutor()
        {

            Kon.Open();
            SqlCommand cmd = new SqlCommand("InsertAutor", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@ImeAutora", SqlDbType.VarChar).Value = txtIme.Text.ToString();
            cmd.Parameters.AddWithValue("@PrezimeAutora", SqlDbType.VarChar).Value = txtPrezime.Text.ToString();
            cmd.Parameters.AddWithValue("@DatumRodjena", SqlDbType.Date).Value = dtpDatum.Value;
            cmd.ExecuteNonQuery();

            Kon.Close();
        }
        private void BrisanjeKontrolaLB()
        {
            txtSifra.Clear();
            txtIme.Clear();
            txtPrezime.Clear();
            dtpDatum.Value = DateTime.Now;
        }

        private void btnUpisi_Click(object sender, EventArgs e)
        {
            InsertAutor();
            PuniListBox();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            BrisanjeKontrolaLB();
        }

        private void btnOdustani_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void analizaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.ShowDialog();
        }

        private void oAplikacijiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.ShowDialog();
        }
    }
}
