﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maturski_ispit_A3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-798ME2F\SQLEXPRESS;Initial Catalog=EIT_A03_EvidencijaRadnika;Integrated Security=True"); /* MM 2 sp*/
        SqlCommand kom = new SqlCommand();

        SqlDataReader dr;

        int id = 0;
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PuniListView();
        }

        private void PuniListView()
        {
            txtSifra.Enabled = false;
            listView1.Items.Clear();

            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniListView", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            //cmd.Parameters.AddWithValue("@Sortiranje", SqlDbType.VarChar).Value = SortKolona;
            //cmd.ExecuteNonQuery();
            //DataTable dt = new DataTable();
            //dt.Load(cmd.ExecuteReader());
            //kom.Connection = Kon;
            //kom.CommandText = "EXEC PuniListView";
            //Kon.Open();
            //dr = kom.ExecuteReader();

            dr = cmd.ExecuteReader();

            while (dr.Read())
            {

                ListViewItem red = new ListViewItem(dr[0].ToString());
                for (int i = 1; i < 6; i++) /* i IDE DO KOLIKO POLJA VRACA PROCEDURA*/
                    red.SubItems.Add(dr[i].ToString());
                listView1.Items.Add(red);
            }
            Kon.Close();
        }

        private void SaListViewNaKontrole()
        {
            foreach (ListViewItem item in listView1.SelectedItems)
            {
                id = Convert.ToInt32(item.SubItems[0].Text);

                txtSifra.Text = id.ToString();
                txtNaziv.Text = item.SubItems[1].Text;
                txtDatum.Text = item.SubItems[2].Text;
                txtBudzet.Text = item.SubItems[3].Text;
                checkZavrsen.Text = item.SubItems[4].Text;
                txtOpis.Text = item.SubItems[5].Text;
                //txtVrednost.Text = item.SubItems[6].Text;
                //dtpDatumPrijema.Value = Convert.ToDateTime(item.SubItems[7].Text);

                //    switch (item.SubItems[8].Text)
                //    {
                //        case "DA":
                //            chkRokTrajanja.Checked = true;
                //            break;
                //        case "NE":
                //            chkRokTrajanja.Checked = false;
                //            break;
                //    }
                //    if (item.SubItems[8].Text == "DA")
                //    {
                //        maskedRokTrajanja.Text = item.SubItems[9].Text;
                //    }
                //}
                //    else
                //{
                //    maskedRokTrajanja.Text = "9999.01.01";
                //}
            }

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SaListViewNaKontrole();
        }

        private void BrisiProjekat()
        {
            string poruka = "Zelite da obrisete stavku?";
            string naslov = "Brisanje proizvoda";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(poruka, naslov, buttons);

            if (result == DialogResult.Yes)
            {
                Kon.Open();
                SqlCommand cmd = new SqlCommand("BrisiProjekat", Kon);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@SifraProjekta", SqlDbType.VarChar).Value = txtSifra.Text.ToString();

                cmd.ExecuteNonQuery();

                Kon.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            BrisiProjekat();
            PuniListView();
            BrisanjeKontrola();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BrisanjeKontrola()
        {
            txtSifra.Clear();
            txtNaziv.Clear();
            txtDatum.Clear();
            txtBudzet.Clear();
            checkZavrsen.Checked = false;
            txtOpis.Clear();
            //txtVrednost.Clear();
            //dtpDatumPrijema.Value = DateTime.Now;
            //maskedRokTrajanja.Text = DateTime.Now.ToString("yyyy.MM.dd");
            checkZavrsen.Checked = false;
            //if (chkRokTrajanja.Checked == true)
            //{
            //    maskedRokTrajanja.Text = DateTime.Now.ToString("yyyy.MM.dd");
            //}
            //else
            //{
            //    maskedRokTrajanja.Text = "9999.01.01";
            //}

        }

        private void pregledProjekataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.ShowDialog();
        }
    }
}
