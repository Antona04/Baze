﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maturski_ispit_A2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-798ME2F\SQLEXPRESS;Initial Catalog=EIT_А02_Biblioteka;Integrated Security=True"); /* MM 2 sp*/
        SqlCommand kom = new SqlCommand();

        SqlDataReader dr;

        int id = 0;

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void PuniComboAutor()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboAutor", Kon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            SifraAutora.DataSource = dt;
            SifraAutora.DisplayMember = "Autor";


            Kon.Close();
        }

        private void PuniGridChart()
        {

            string Par_Autor = SifraAutora.Text.ToString();
            string[] PAutor = Par_Autor.Split('-');

            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniGridChart", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("SifraAutora", SqlDbType.VarChar).Value = PAutor[0].ToString().Trim();
            cmd.Parameters.AddWithValue("@Period", SqlDbType.VarChar).Value = numericUpDown1.Value.ToString();
            //cmd.Parameters.AddWithValue("@Period", SqlDbType.VarChar).Value = numericUpDown1.Value.ToString();
            //cmd.Parameters.AddWithValue("@Param3", SqlDbType.VarChar).Value = checkedListBox1.CheckedItems[2].ToString();

            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            chart1.DataSource = dt;
            dataGridView1.DataSource = dt;

            chart1.Series["Series1"].XValueMember = "GodUzimanja";
            chart1.Series["Series1"].YValueMembers = "BrIznajmljivanja";
            chart1.Titles.Add(SifraAutora.Text);

            Kon.Close();
            chart1.Titles.Clear();
        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

            PuniComboAutor();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PuniGridChart();
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
