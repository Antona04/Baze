﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace Maturski_ispit_A13
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-798ME2F\SQLEXPRESS;Initial Catalog=4EIT_A13_DVDKolekcija;Integrated Security=True"); /* MM 2 sp*/

        SqlCommand kom = new SqlCommand();

        SqlDataReader dr;

        int id = 0;

        private void toolStripContainer1_ContentPanel_Load(object sender, EventArgs e)
        {

        }

        private void PuniListBox()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniListBox", Kon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            listBox1.DataSource = dt;
            listBox1.DisplayMember = "NAZIV";


            Kon.Close();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PuniListBox();
        }

        private void listBox1_Click(object sender, EventArgs e)
        {
            string Par_Proizvod = listBox1.Text.ToString();
            string[] PProizvod = Par_Proizvod.Split('-');

            txtSifra.Text = PProizvod[0].ToString().Trim();
            txtIme.Text = PProizvod[1].ToString().Trim();
            txtEmail.Text = PProizvod[2].ToString().Trim();
            //cmbKategorijaLB.Text = PProizvod[3].ToString().Trim();
            //txtCenaLB.Text = PProizvod[4].ToString().Trim();
            //txtKolicinaLB.Text = PProizvod[5].ToString().Trim();
            //txtVrednostLB.Text = PProizvod[6].ToString().Trim();
            //dtpDatumPrijemaLB.Value = Convert.ToDateTime(PProizvod[7].ToString().Trim());

            //switch (PProizvod[8].ToString().Trim())
            //{
            //    case "DA":
            //        chkRokTrajanjaLB.Checked = true;
            //        break;
            //    case "NE":
            //        chkRokTrajanjaLB.Checked = false;
            //        break;
            //}
        }

        private void IzmeniUpdate()
        {
            string poruka = "Zelite da izmenite stavku?";
            string naslov = "Izmena";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(poruka, naslov, buttons);

            if (result == DialogResult.Yes)
            {
                Kon.Open();
                SqlCommand cmd = new SqlCommand("IzmeniUpdate", Kon);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ProducentID", SqlDbType.VarChar).Value = txtSifra.Text.ToString();
                cmd.Parameters.AddWithValue("@Ime", SqlDbType.VarChar).Value = txtSifra.Text.ToString();
                cmd.Parameters.AddWithValue("@Email", SqlDbType.VarChar).Value = txtEmail.Text.ToString();
                //cmd.Parameters.AddWithValue("@Kategorija", SqlDbType.VarChar).Value = cmbKategorijaLB.Text.ToString();
                //cmd.Parameters.AddWithValue("@Cena", SqlDbType.VarChar).Value = txtCenaLB.Text.ToString();
                //cmd.Parameters.AddWithValue("@Kolicina", SqlDbType.VarChar).Value = txtKolicinaLB.Text.ToString();
                //cmd.Parameters.AddWithValue("@DatumPrijema", SqlDbType.Date).Value = dtpDatumPrijemaLB.Value;
                //cmd.Parameters.AddWithValue("@RokTrajanja", SqlDbType.VarChar).Value = Convert.ToDateTime(maskedRokTrajanjaLB.Text);
                //cmd.Parameters.AddWithValue("@ImaRokTrajanja", SqlDbType.VarChar).Value = chkRokTrajanjaLB.Checked.ToString();

                cmd.ExecuteNonQuery();

                Kon.Close();
            }
        }

        private void izmeniToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IzmeniUpdate();
            PuniListBox();
        }

        private void analizaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.ShowDialog();
        }

        private void izlazToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void oAplikacijiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.ShowDialog();
        }

        private void txtIme_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
