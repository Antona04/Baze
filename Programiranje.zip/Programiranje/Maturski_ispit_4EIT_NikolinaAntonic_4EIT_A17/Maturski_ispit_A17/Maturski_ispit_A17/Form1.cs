﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maturski_ispit_A17
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-798ME2F\SQLEXPRESS;Initial Catalog=4EIT_A17_EvidencijaVozila;Integrated Security=True"); /* MM 2 sp*/

        SqlCommand kom = new SqlCommand();

        SqlDataReader dr;

        int id = 0;
        private void Form1_Load(object sender, EventArgs e)
        {
            button2.Visible = false;
            PuniListView();
            PuniComboModel();
            PuniComboGorivo();
            PuniComboBoja();
        }

        private void PuniListView()
        {

            listView1.Items.Clear();

            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniListBoxView", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            dr = cmd.ExecuteReader();

            while (dr.Read())
            {

                ListViewItem red = new ListViewItem(dr[0].ToString());
                for (int i = 1; i < 11; i++) /* i IDE DO KOLIKO POLJA VRACA PROCEDURA*/
                    red.SubItems.Add(dr[i].ToString());
                listView1.Items.Add(red);
            }
            Kon.Close();
        }
        private void SaListViewNaKontrole()
        {
            foreach (ListViewItem item in listView1.SelectedItems)
            {
                id = Convert.ToInt32(item.SubItems[0].Text);

                txtSifra.Text = id.ToString();
                txtRegistracija.Text = item.SubItems[1].Text;
                txtGodina.Text = item.SubItems[2].Text;
                txtPredjeno.Text = item.SubItems[3].Text;
                txtCena.Text = item.SubItems[7].Text;
                cmbModel.Text = item.SubItems[8].Text;
                cmbBoja.Text = item.SubItems[9].Text;
                cmbGorivo.Text = item.SubItems[10].Text;
            }
        }
        private void izmeniToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AzurirajPodatkeVozilo();
            PuniListView();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SaListViewNaKontrole();
        }
        private void PuniComboModel()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboModel", Kon);
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            cmbModel.DataSource = dt;
            cmbModel.DisplayMember = "Naziv";

            Kon.Close();
        }
        private void PuniComboBoja()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboBoja", Kon);
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            cmbBoja.DataSource = dt;
            cmbBoja.DisplayMember = "Naziv";

            Kon.Close();
        }
        private void PuniComboGorivo()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboGorivo", Kon);
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            cmbGorivo.DataSource = dt;
            cmbGorivo.DisplayMember = "Naziv";

            Kon.Close();
        }

        private void izlazToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmbModel_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtSifra.Enabled = false;
            button2.Visible = true;
        }
        private void AzurirajPodatkeVozilo()
        {
            Kon.Open();
            SqlCommand cmd = new SqlCommand("AzurirajPodatkeVozilo", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@Registracija", SqlDbType.VarChar).Value = txtRegistracija.Text.ToString();
            cmd.Parameters.AddWithValue("@GodinaProizvodnje", SqlDbType.VarChar).Value = txtGodina.Text.ToString();
            cmd.Parameters.AddWithValue("@Kilometraza", SqlDbType.VarChar).Value = txtPredjeno.Text.ToString();
            cmd.Parameters.AddWithValue("@ModelNaziv", SqlDbType.VarChar).Value = cmbModel.Text.ToString();
            cmd.Parameters.AddWithValue("@BojaNaziv", SqlDbType.VarChar).Value = cmbBoja.Text.ToString();
            cmd.Parameters.AddWithValue("@GorivoNaziv", SqlDbType.VarChar).Value = cmbGorivo.Text.ToString();
            cmd.Parameters.AddWithValue("@Cena", SqlDbType.VarChar).Value = txtCena.Text.ToString();
            cmd.Parameters.AddWithValue("@VoziloID", SqlDbType.VarChar).Value = txtSifra.Text.ToString();

            cmd.ExecuteNonQuery();

            Kon.Close();
        }
        private void BrisanjeKontrola()
        {
            txtSifra.Clear();
            txtRegistracija.Clear();
            txtCena.Clear();
            txtGodina.Clear();
            txtPredjeno.Clear();
        }
        private void analizaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.ShowDialog();
        }

        private void oAplikacijiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.ShowDialog();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            BrisanjeKontrola();
            button2.Visible = false;
            txtSifra.Enabled = true;
        }
    }
}
