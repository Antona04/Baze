﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maturski_ispit_A19
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-798ME2F\SQLEXPRESS;Initial Catalog=4EIT_A19_EvidencijaZaposlenih;Integrated Security=True"); /* MM 2 sp*/

        SqlCommand kom = new SqlCommand();

        SqlDataReader dr;

        int id = 0;
        private void Form1_Load(object sender, EventArgs e)
        {
            PuniComboSektor();
            btnPromena.Enabled = false;
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void PuniComboSektor()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboSektor", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            comboSektor.DataSource = dt;
            comboSektor.DisplayMember = "Naziv";

            Kon.Close();
        }
        private void comboSektor_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnPromena.Enabled = true;
        }
        private void PuniListView()
        {
            listView1.Items.Clear();
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniListView", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@SektorNaziv", SqlDbType.NVarChar).Value = comboSektor.Text.ToString();

            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                ListViewItem item = new ListViewItem(dr[0].ToString());
                for (int i = 1; i < 5; i++)
                {
                    item.SubItems.Add(dr[i].ToString());
                }
                listView1.Items.Add(item);
            }

            Kon.Close();
        }
    
        private void comboSektor_SelectionChangeCommitted(object sender, EventArgs e)
        {
            PuniListView();
            PuniOpis();
        }
        private void PuniOpis()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("Opis", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@SektorNaziv", SqlDbType.NVarChar).Value = comboSektor.Text.ToString();
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                txtPodaci.Text = dr[1].ToString() + " rukovodioc postavljen : " + dr[0].ToString();
            }

            Kon.Close();
            PuniPodatkeOSektoru();
        }
        private void PuniPodatkeOSektoru()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniPodatkeOSektoru", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@SektorNaziv", SqlDbType.NVarChar).Value = comboSektor.Text.ToString();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                txtPodaci.Text += "\n " + dr[0].ToString();
            }

            Kon.Close();
        }

        private void btnPromena_Click(object sender, EventArgs e)
        {
            Form2 forma = new Form2();
            DialogResult result = forma.ShowDialog();

            if (result == DialogResult.OK)
            {
                int id = forma.ID;
                string datum = forma.datum;
                ZamenaRukovodioca(id, datum);
                PuniListView();
            }
        }
        private void ZamenaRukovodioca(int x, string y)
        {
            Kon.Open();

            SqlCommand cmd2 = new SqlCommand("ZatvaraStariRukovodioc", Kon);
            cmd2.CommandType = CommandType.StoredProcedure;

            cmd2.Parameters.AddWithValue("@DatumPostavljanja", SqlDbType.NVarChar).Value = y;
            cmd2.ExecuteNonQuery();

            SqlCommand cmd = new SqlCommand("NoviRukovodioc", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@RadnikID", SqlDbType.Int).Value = x;
            cmd.Parameters.AddWithValue("@DatumPostavljanja", SqlDbType.NVarChar).Value = y;

            cmd.ExecuteNonQuery();

            Kon.Close();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Form3 forma = new Form3();
            forma.ShowDialog();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
