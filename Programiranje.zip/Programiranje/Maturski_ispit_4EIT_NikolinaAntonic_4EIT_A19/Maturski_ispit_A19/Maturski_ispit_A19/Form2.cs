﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maturski_ispit_A19
{
    public partial class Form2 : Form
    {
        public int ID { get; set; }
        public string datum { get; set; }
        public Form2()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-798ME2F\SQLEXPRESS;Initial Catalog=4EIT_A19_EvidencijaZaposlenih;Integrated Security=True"); /* MM 2 sp*/

        SqlCommand kom = new SqlCommand();

        SqlDataReader dr;

        int id = 0;
        private void Form2_Load(object sender, EventArgs e)
        {
            PuniComboBox();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Radnik = comboBox1.Text.ToString();
            string[] id = Radnik.Split('-');
            ID = Convert.ToInt32(id[0].Trim());
            datum = maskedTextBox1.Text.ToString();
            DialogResult = DialogResult.OK;
        }
        private void PuniComboBox()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboNoviRukovodioc", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "Radnik";

            Kon.Close();
        }
    }
}
