﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maturski_ispit_A10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-798ME2F\SQLEXPRESS;Initial Catalog=4EIT_A10_RibolovackoDrustvo;Integrated Security=True"); /* MM 2 sp*/

        SqlCommand kom = new SqlCommand();

        SqlDataReader dr;

        int id = 0;

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PuniListBox();
            PuniComboGrad();
        }

        private void PuniListBox()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniListBox", Kon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            listBox1.DataSource = dt;
            listBox1.DisplayMember = "Pecaros";

            Kon.Close();

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void listBox1_Click(object sender, EventArgs e)
        {
            string Par_Pecaros = listBox1.Text.ToString();
            string[] PPecaros = Par_Pecaros.Split('*');

            txtSifra.Text = PPecaros[0].ToString().Trim();
            txtIme.Text = PPecaros[1].ToString().Trim();
            txtPrezime.Text = PPecaros[2].ToString().Trim();
            txtAdresa.Text = PPecaros[3].ToString().Trim();
            cmbGrad.Text = PPecaros[4].ToString().Trim();
            txtTelefon.Text = PPecaros[5].ToString().Trim();

        }

        private void PuniComboGrad()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboGrad", Kon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            cmbGrad.DataSource = dt;
            cmbGrad.DisplayMember = "Grad";

            //cmbKategorijaLB.DataSource = dt;
            //cmbKategorijaLB.DisplayMember = "Kategorija";

            Kon.Close();
        }

        private void IzmeniUpdatePecaros()
        {
            Kon.Open();
            SqlCommand cmd = new SqlCommand("IzmeniUpdatePecaros", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@PecarosID", SqlDbType.VarChar).Value = txtSifra.Text.ToString();
            cmd.Parameters.AddWithValue("@Ime", SqlDbType.VarChar).Value = txtIme.Text.ToString();
            cmd.Parameters.AddWithValue("@Prezime", SqlDbType.VarChar).Value = txtPrezime.Text.ToString();
            cmd.Parameters.AddWithValue("@Adresa", SqlDbType.VarChar).Value = txtAdresa.Text.ToString();
            cmd.Parameters.AddWithValue("@Grad", SqlDbType.VarChar).Value = cmbGrad.Text.ToString();
            cmd.Parameters.AddWithValue("@Telefon", SqlDbType.VarChar).Value = txtTelefon.Text.ToString();

            cmd.ExecuteNonQuery();

            Kon.Close();
        }

        private void izmenaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IzmeniUpdatePecaros();
            PuniListBox();
        }

        private void analizaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.ShowDialog();
        }

        private void izlazToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void oAplikacijiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.ShowDialog();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
