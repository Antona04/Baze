﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maturski_ispit_A10
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }


        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-798ME2F\SQLEXPRESS;Initial Catalog=4EIT_A10_RibolovackoDrustvo;Integrated Security=True"); /* MM 2 sp*/

        SqlCommand kom = new SqlCommand();

        SqlDataReader dr;

        int id = 0;

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void PuniComboPecaros()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboPecaros", Kon);
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            cmbPecaros.DataSource = dt;
            cmbPecaros.DisplayMember = "Pecaros";



            Kon.Close();
        }

        private void PuniGridiChart()
        {
            string Par_Pecaros = cmbPecaros.Text.ToString();
            string[] PPecaros = Par_Pecaros.Split('-');

            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniGridiChart", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@PecarosID", SqlDbType.VarChar).Value = PPecaros[0].ToString().Trim();
            cmd.Parameters.AddWithValue("@DatumOD", SqlDbType.VarChar).Value = dateTimePicker1.Value.ToString();
            cmd.Parameters.AddWithValue("@DatumDO", SqlDbType.VarChar).Value = dateTimePicker2.Value.ToString();

            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            chart1.DataSource = dt;
            dataGridView1.DataSource = dt;

            chart1.Series["Series1"].XValueMember = "Broj";
            chart1.Series["Series1"].YValueMembers = "Naziv";
            chart1.Titles.Add(cmbPecaros.Text);

            Kon.Close();
        }

        private void Prikazi_Click(object sender, EventArgs e)
        {
            PuniGridiChart();
            chart1.Titles.Clear();
        }

        private void Izadji_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
