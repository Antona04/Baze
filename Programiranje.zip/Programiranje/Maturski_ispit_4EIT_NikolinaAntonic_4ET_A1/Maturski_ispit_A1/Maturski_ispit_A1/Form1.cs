﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maturski_ispit_A1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-798ME2F\SQLEXPRESS;Initial Catalog=EIT_А01_Biblioteka;Integrated Security=True"); /* MM 2 sp*/

        SqlCommand kom = new SqlCommand();

        SqlDataReader dr;

        int id = 0;

        private void PuniListView()
        {

            listView1.Items.Clear();

            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniListView", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            //cmd.Parameters.AddWithValue("@Sortiranje", SqlDbType.VarChar).Value = SortKolona;
            //cmd.ExecuteNonQuery();
            //DataTable dt = new DataTable();
            //dt.Load(cmd.ExecuteReader());
            //kom.Connection = Kon;
            //kom.CommandText = "EXEC PuniListView";
            //Kon.Open();
            //dr = kom.ExecuteReader();

            dr = cmd.ExecuteReader();

            while (dr.Read())
            {

                ListViewItem red = new ListViewItem(dr[0].ToString());
                for (int i = 1; i < 4; i++) /* i IDE DO KOLIKO POLJA VRACA PROCEDURA*/
                    red.SubItems.Add(dr[i].ToString());
                listView1.Items.Add(red);
            }
            Kon.Close();
        }

        private void UnesiAutora()
        {
            Kon.Open();
            SqlCommand cmd = new SqlCommand("UnesiAutora", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@ImeAutor", SqlDbType.VarChar).Value = textBox2.Text.ToString();
            cmd.Parameters.AddWithValue("@PrezimemeAutor", SqlDbType.VarChar).Value = textBox3.Text.ToString();
            cmd.Parameters.AddWithValue("@DatumRAutor", SqlDbType.Date).Value = Convert.ToDateTime(maskedTextBox1.Text);


            cmd.ExecuteNonQuery();

            Kon.Close();
        }

        private void SaListViewNaKontrole()
        {
            foreach (ListViewItem item in listView1.SelectedItems)
            {
                id = Convert.ToInt32(item.SubItems[0].Text);

                textBox1.Text = id.ToString();
                textBox2.Text = item.SubItems[1].Text;
                textBox3.Text = item.SubItems[2].Text;
                maskedTextBox1.Text = item.SubItems[3].Text;


                ////switch (item.SubItems[8].Text)
                ////{
                //    //case "DA":
                //        //chkRokTrajanja.Checked = true;
                //        //break;
                //    case "NE":
                //        chkRokTrajanja.Checked = false;
                //        break;
                //}
                //if (item.SubItems[8].Text == "DA")
                //{
                //    maskedRokTrajanja.Text = item.SubItems[9].Text;
                //}
                //else
                //{
                //    maskedRokTrajanja.Text = "9999.01.01";
                //}
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PuniListView();
        }

        private void label1_Click(object sender, EventArgs e)
        {
           
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SaListViewNaKontrole();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            UnesiAutora();
            PuniListView();
        }

        private void analizaIznajmljivanjaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.ShowDialog();
        }

        private void oAplikacijiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.ShowDialog();
        }
    }
}
