﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace Maturski_ispit_A1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-798ME2F\SQLEXPRESS;Initial Catalog=EIT_А01_Biblioteka;Integrated Security=True"); /* MM 2 sp*/

        SqlCommand kom = new SqlCommand();

        SqlDataReader dr;

        int id = 0;

        private void PuniGridChart()
        {

            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniGridChart", Kon);
            cmd.CommandType = CommandType.StoredProcedure;


            cmd.Parameters.AddWithValue("@SifraAutora", SqlDbType.VarChar).Value = 11;
            cmd.Parameters.AddWithValue("@BrIznajmljivanja", SqlDbType.VarChar).Value = 1;
            cmd.Parameters.AddWithValue("@Period", SqlDbType.VarChar).Value = 1;

            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            chart1.DataSource = dt;
            dataGridView1.DataSource = dt;

            chart1.Series["Series1"].XValueMember = "Autor";
            chart1.Series["Series1"].YValueMembers = "GodUzimanja";
            chart1.Titles.Add("PRIMER CHART");

            

            Kon.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
         
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void podaciOAutorimaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            PuniGridChart();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void PuniComboKategorija(object sender, EventArgs e)
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("SELECT(a.Ime + ' ' + a.Prezime) as ime FROM Autor a", Kon);
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "Autor";


            Kon.Close();
        }

        private void oAplikacijiToolStripMenuItem_Click(object sender, EventArgs e)
        {
                Form3 form3 = new Form3();
                form3.ShowDialog();
        }
    }
 }

