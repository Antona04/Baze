﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maturski_ispit_A7
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }


        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-798ME2F\SQLEXPRESS;Initial Catalog=4EIT_A7_FakultetskaEvidencija;Integrated Security=True"); /* MM 2 sp*/

        SqlCommand kom = new SqlCommand();

        SqlDataReader dr;

        int id = 0;

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            PuniGrid();
            txtID.Enabled = false;
        }

        private void PuniGrid()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniGrid", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            dataGridView1.DataSource = dt;

            Kon.Close();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtSifra.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtPredmet.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtSemestar.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            txtOpis.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
        }

        private void BrisiPredmet()
        {
            string poruka = "Zelite da obrisete stavku?";
            string naslov = "Brisanje proizvoda";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(poruka, naslov, buttons);

            if (result == DialogResult.Yes)
            {
                Kon.Open();
                SqlCommand cmd = new SqlCommand("BrisiPredmet", Kon);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@PredmetID", SqlDbType.VarChar).Value = txtID.Text.ToString();

                cmd.ExecuteNonQuery();

                Kon.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            BrisiPredmet();
            PuniGrid();
            BrisanjeKontrola();
        }

        private void BrisanjeKontrola()
        {
            txtID.Clear();
            txtSifra.Clear();
            txtPredmet.Clear();
            txtSemestar.Clear();
            txtOpis.Clear();
        }
    }
}
