﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maturski_ispit_A16
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-798ME2F\SQLEXPRESS;Initial Catalog=4EIT_A16_IzlozbaPasa;Integrated Security=True"); /* MM 2 sp*/

        SqlCommand kom = new SqlCommand();

        SqlDataReader dr;

        int id = 0;


        private void Form1_Load(object sender, EventArgs e)
        {
            PuniComboPas();
            PuniComboIzlozba();
            PuniComboKategorija();
            PuniComboIzlozba2();
        }

        private void PuniComboPas()
        {

            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboPas", Kon);
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            cmbPas.DataSource = dt;
            cmbPas.DisplayMember = "Pas";


            Kon.Close();
        }

        private void PuniComboIzlozba()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboIzlozba", Kon);
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            cmbIzlozba.DataSource = dt;
            cmbIzlozba.DisplayMember = "Izlozba";

            Kon.Close();
        }

        private void PuniComboKategorija()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboKategorija", Kon);
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            cmbKategorija.DataSource = dt;
            cmbKategorija.DisplayMember = "Kategorija";

            Kon.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void PrijavaPasa()
        {
            string Par_Proizvod = cmbPas.Text.ToString();
            string[] PProizvod = Par_Proizvod.Split('-');
            string Par_Proizvod1 = cmbIzlozba.Text.ToString();
            string[] PProizvod1 = Par_Proizvod1.Split('-');
            string Par_Proizvod2 = cmbKategorija.Text.ToString();
            string[] PProizvod2 = Par_Proizvod2.Split('-');
            Kon.Open();
            SqlCommand cmd = new SqlCommand("PrijavaPasa", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@IzlozbaID", SqlDbType.VarChar).Value = PProizvod1[0].ToString().Trim();
            cmd.Parameters.AddWithValue("@KategorijaID", SqlDbType.VarChar).Value = PProizvod2[0].ToString().Trim();
            cmd.Parameters.AddWithValue("@PasID", SqlDbType.VarChar).Value = PProizvod[0].ToString().Trim();
            cmd.ExecuteNonQuery();

            Kon.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            PrijavaPasa();
        }
        private void PuniComboIzlozba2()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboIzlozba", Kon);
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            cmbIzlozba2.DataSource = dt;
            cmbIzlozba2.DisplayMember = "Izlozba";

            Kon.Close();
        }
        private void tabPage4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void PuniGridIChart()
        {

            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniGridIChart", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@IzlozbaID", SqlDbType.VarChar).Value = cmbIzlozba2.Text.ToString();


            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            chart1.DataSource = dt;
            dataGridView1.DataSource = dt;

            chart1.Series["Series1"].XValueMember = "Naziv";
            chart1.Series["Series1"].YValueMembers = "Brojpasa";
            chart1.Titles.Add("");

            Kon.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PuniGridIChart();
            chart1.Titles.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
